package menu;

import animation.Animation;

/**
 * The interface Menu.
 *
 * @param <T> the type parameter
 */
public interface Menu<T> extends Animation {
    /**
     * Add selection.
     *
     * @param key       the key
     * @param message   the message
     * @param returnVal the return val
     * @param subMenu   the sub menu
     */
    void addSelection(String key, String message, T returnVal, Menu subMenu);

    /**
     * Gets status.
     *
     * @return the status
     */
    T getStatus();

    /**
     * Add sub menu.
     *
     * @param key     the key
     * @param message the message
     * @param o       the o
     * @param subMenu the sub menu
     */
    void addSubMenu(String key, String message, Object o, Menu<T> subMenu);

    /**
     * Sets stop.
     *
     * @param stop the stop
     */
    void setStop(boolean stop);

    /**
     * Rest method.
     */
    void rest();
}